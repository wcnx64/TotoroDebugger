protected.vmp.exe is protected by VMProtect3.5.

VMProtectBegin("Cipher")
inline AES Cipher
VMProtectEnd()

run TotoroDebugger.exe to get the AES key.
it may take several minutes.
